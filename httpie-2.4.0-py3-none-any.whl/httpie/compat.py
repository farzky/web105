import sys


is_windows = 'win32' in str(sys.platform).lower()
